import http from 'http';
import path from 'path';
import express from 'express';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { apiRouter } from './server/routes.ts';
import { marketProvider } from './server/market/dataProvider.ts';
import { marketIntelligence } from './server/intel/marketIntelligence.ts';
import { liveOutcomeTracker } from './server/market/outcomeTracker.ts';
import { startSourceIngest } from './server/engine/sourceIngest.ts';
import { signalEmitter } from './server/engine/signalEmitter.ts';
import { sqliteStore } from './server/db/sqliteStore.ts';

dotenv.config();

const app = express();
const port = 3000;
const isDev = process.env.NODE_ENV !== 'production';

app.use(express.json());

// API Routes
app.use('/api', apiRouter);

const server = http.createServer(app);

// WebSocket Server attached to HTTP server
const wss = new WebSocketServer({ server, path: '/ws' });
const clients = new Set<WebSocket>();
let messageSeq = 0;

wss.on('connection', (ws) => {
  clients.add(ws);

  // Send initial welcome & heartbeat state
  ws.send(
    JSON.stringify({
      type: 'INIT',
      seq: ++messageSeq,
      serverTs: Date.now(),
      symbols: marketProvider.getAllSymbols(),
      health: marketProvider.getHealth(),
      latestSourceSignals: {
        INDICATOR: sqliteStore.getAllSignals({ source: 'INDICATOR', origin: 'engine_live', limit: 1 }).signals[0] || null,
        ANALYSIS: sqliteStore.getAllSignals({ source: 'ANALYSIS', origin: 'engine_live', limit: 1 }).signals[0] || null,
      },
    })
  );

  ws.on('message', (message) => {
    try {
      const parsed = JSON.parse(message.toString());
      if (parsed.type === 'PING') {
        ws.send(
          JSON.stringify({
            type: 'PONG',
            seq: ++messageSeq,
            serverTs: Date.now(),
            clientTs: parsed.timestamp,
          })
        );
      }
    } catch (e) {
      // ignore malformed ws messages
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
  });

  ws.on('error', () => {
    clients.delete(ws);
  });
});

// Broadcast real-time ticks to connected WebSocket clients
marketProvider.subscribe((symbol, tick) => {
  const symData = marketProvider.getSymbolData(symbol);
  if (!symData) return;

  const seq = ++messageSeq;
  const serverTs = Date.now();

  const payload = JSON.stringify({
    type: 'TICK',
    seq,
    serverTs,
    symbol,
    price: tick.price,
    bid: tick.bid,
    ask: tick.ask,
    spread: tick.spread,
    latencyMs: symData.latencyMs,
    isStale: symData.isStale,
    isDelayed: symData.isDelayed,
    isDivergent: symData.isDivergent,
    time: tick.time,
    isForming: tick.isForming,
  });

  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
});

// Broadcast live outcome events (TP hit, SL hit, BE exit) to connected WebSocket clients
liveOutcomeTracker.onBroadcast((payload) => {
  const jsonStr = JSON.stringify(payload);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(jsonStr);
    }
  }
});

signalEmitter.onSignalCreated((payload) => {
  const message = JSON.stringify({ ...payload, seq: ++messageSeq, serverTs: Date.now() });
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  }
});

async function startServer() {
  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`QRA Gold Terminal running at http://0.0.0.0:${port}`);
  });

  // Start market data feed & market intelligence asynchronously in background
  startSourceIngest();
  marketProvider.start().catch((err) => {
    console.warn('Market provider startup warning:', err);
  });
  marketIntelligence.start().catch((err) => {
    console.warn('Market intelligence startup warning:', err);
  });
  liveOutcomeTracker.start().catch((err) => {
    console.warn('Live outcome tracker startup warning:', err);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
