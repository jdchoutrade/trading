# QRA Terminal Setup & Environment Configuration Guide

## 1. Environment Variables (.env)

Create a `.env` file in the project root:

```bash
# Gemini API Key (Automatically injected in Google AI Studio)
GEMINI_API_KEY="your-gemini-api-key"

# DeepSeek API Key (Optional: for deepseek-chat or deepseek-reasoner R1)
DEEPSEEK_API_KEY=""

# Telegram Bot Integration (Optional: for live trade broadcasting)
TELEGRAM_BOT_TOKEN=""
TELEGRAM_CHAT_ID=""
```

## 2. Running Unit Tests

The SMC quantitative engine features a 100% automated test suite using `vitest`:

```bash
npm test
```

## 3. Keyboard Shortcuts

- `⌘ / Ctrl + F`: Open "Ask QRA" interactive AI assistant
- `⌘ / Ctrl + S`: Open 12-Step Quant Setup Plan side drawer
- `⌘ / Ctrl + B`: Toggle between Indicators custom chart and TradingView live widget
- `⌘ / Ctrl + ?`: View keyboard shortcuts reference

## 4. How Indicators & SMC Levels Are Calculated

- **BOS & CHoCH:** Evaluates previous fractal swing highs/lows. A candle body close above a swing high marks a BOS (continuation) or CHoCH (reversal). Wicks do not qualify.
- **Order Blocks (OB):** Identifies the last opposing candle prior to a displacement move exceeding 1.3× ATR(14). Tracks subsequent bars to detect mitigation.
- **Fair Value Gaps (FVG):** Measured across 3 consecutive candles where candle 1 high and candle 3 low do not overlap with a gap ≥ 0.3× ATR. Tracks fill percentage.
- **Liquidity Sweeps:** Detected when a candle's wick breaks past a swing point or session extreme but the body closes back within the boundary.
- **Position Sizing:** `Lot Size = (Account Balance × Risk %) / (SL Distance in Points × 100)`.
