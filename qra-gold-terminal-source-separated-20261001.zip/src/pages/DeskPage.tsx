import React, { useEffect, useState, useRef } from 'react';
import { useTerminal } from '../context/TerminalContext.tsx';
import {
  createChart,
  ColorType,
  IChartApi,
  CandlestickSeries,
  CandlestickData,
  Time,
} from 'lightweight-charts';
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart2,
  CheckCircle,
  Clock,
  Compass,
  DollarSign,
  Globe,
  Layers,
  Percent,
  Radio,
  RefreshCw,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';
import {
  CorrelationMatrixItem,
  CrossAssetQuote,
  MacroDataPoint,
  MarketNewsStory,
  RiskOffClassification,
  ScenarioItem,
  ShockAlert,
} from '../types.ts';

export const DeskPage: React.FC = () => {
  const { snapshot, candles, currentPrice, activeSymbol, activeTimeframe, runAnalysisWithAnimation, setIsAskQraOpen } = useTerminal();

  const [deskData, setDeskData] = useState<{
    crossAssets: CrossAssetQuote[];
    correlations: CorrelationMatrixItem[];
    macro: MacroDataPoint[];
    riskOff: RiskOffClassification;
    scenarios: ScenarioItem[];
    griIndex: number;
    recentStories: MarketNewsStory[];
    activeShock: ShockAlert | null;
  } | null>(null);

  const [loading, setLoading] = useState<boolean>(true);

  // Chart ref
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<any>(null);

  // Fetch Desk bundle
  const loadDeskData = async () => {
    try {
      const res = await fetch('/api/desk');
      const json = await res.json();
      if (json.success) {
        setDeskData(json);
      }
    } catch (e) {
      console.warn('Failed to load desk data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDeskData();
    const interval = setInterval(loadDeskData, 20000);
    return () => clearInterval(interval);
  }, []);

  // Mini Chart init
  useEffect(() => {
    if (!chartContainerRef.current) return;

    if (chartRef.current) {
      chartRef.current.remove();
      chartRef.current = null;
    }

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      layout: {
        background: { type: ColorType.Solid, color: '#090d14' },
        textColor: '#64748b',
        fontSize: 10,
        fontFamily: "'JetBrains Mono', monospace",
      },
      grid: {
        vertLines: { color: 'rgba(255, 255, 255, 0.02)' },
        horzLines: { color: 'rgba(255, 255, 255, 0.02)' },
      },
      timeScale: {
        borderColor: 'rgba(255, 255, 255, 0.06)',
        timeVisible: true,
      },
      rightPriceScale: {
        borderColor: 'rgba(255, 255, 255, 0.06)',
      },
    });

    chartRef.current = chart;

    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#22E58B',
      downColor: '#FF4D6D',
      borderVisible: false,
      wickUpColor: '#22E58B',
      wickDownColor: '#FF4D6D',
    });
    candleSeriesRef.current = candleSeries;

    if (candles && candles.length > 0) {
      const formatted: CandlestickData<Time>[] = candles.slice(-100).map((c) => ({
        time: c.time as Time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      candleSeries.setData(formatted);
      chart.timeScale().fitContent();
    }

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartRef.current) {
        chartRef.current.remove();
        chartRef.current = null;
      }
    };
  }, [candles]);

  // Real-time tick update
  useEffect(() => {
    if (!candleSeriesRef.current || !candles || candles.length === 0) return;
    const last = candles[candles.length - 1];
    candleSeriesRef.current.update({
      time: last.time as Time,
      open: last.open,
      high: Math.max(last.high, currentPrice),
      low: Math.min(last.low, currentPrice),
      close: currentPrice,
    });
  }, [currentPrice, candles]);

  const riskOff = deskData?.riskOff || snapshot?.riskOff;
  const gri = deskData?.griIndex || snapshot?.griIndex || 42;
  const shock = deskData?.activeShock || snapshot?.activeShock;

  return (
    <div className="flex-1 bg-[#07090d] overflow-y-auto p-4 space-y-4 font-mono select-none">
      {/* Top Cross-Asset Ticker Ribbon */}
      <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-3 shadow-lg">
        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2 border-b border-white/[0.04] pb-1.5">
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-[#3DDCFF]" />
            <span className="font-bold text-slate-200">CROSS-ASSET MACRO STRIP</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Live Stream
            </span>
          </div>
          <span className="text-[10px] text-slate-500">Updated: real-time Yahoo / TV sync</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-2">
          {(deskData?.crossAssets || []).map((asset) => (
            <div
              key={asset.symbol}
              className="bg-black/30 border border-white/[0.04] rounded-lg p-2 flex flex-col justify-between"
            >
              <div className="flex justify-between items-center text-[10px] text-slate-400">
                <span className="font-bold text-slate-200">{asset.symbol}</span>
                <span className={asset.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
                </span>
              </div>
              <div className="text-xs font-bold text-slate-100 mt-1">
                {asset.price < 10 ? asset.price.toFixed(3) : asset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Grid: Live Chart + Signal Fusion Waterfall */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: XAUUSD Live Snapshot & Macro Overview */}
        <div className="lg:col-span-2 space-y-4">
          {/* Live Mini Chart Container */}
          <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-base font-bold text-slate-100">XAUUSD Gold Spot</span>
                  <span className="text-2xl font-bold text-[#F5C451]">${currentPrice.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px]">
                  <Radio className="w-3 h-3 animate-pulse" />
                  <span>Real-time Tick Stream</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={runAnalysisWithAnimation}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#F5C451] hover:bg-[#e0b03e] text-black font-bold text-xs shadow"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Run Pipeline</span>
                </button>
                <button
                  onClick={() => setIsAskQraOpen(true)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-white/[0.05] hover:bg-white/[0.08] text-slate-200 text-xs border border-white/[0.08]"
                >
                  <span>Ask QRA</span>
                </button>
              </div>
            </div>

            <div className="h-64 w-full rounded-lg overflow-hidden border border-white/[0.04]">
              <div ref={chartContainerRef} className="w-full h-full" />
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
              <div className="bg-black/30 p-2 rounded border border-white/[0.04]">
                <span className="text-[10px] text-slate-500 block">Spread</span>
                <span className="font-bold text-slate-200">${(snapshot?.spread || 0.35).toFixed(2)}</span>
              </div>
              <div className="bg-black/30 p-2 rounded border border-white/[0.04]">
                <span className="text-[10px] text-slate-500 block">ATR (14)</span>
                <span className="font-bold text-slate-200">{snapshot?.atr14 ? snapshot.atr14.toFixed(2) : '3.80'} pts</span>
              </div>
              <div className="bg-black/30 p-2 rounded border border-white/[0.04]">
                <span className="text-[10px] text-slate-500 block">Active Regime</span>
                <span className="font-bold text-cyan-400">{snapshot?.regime.type.replace('TREND_', '') || 'RANGE'}</span>
              </div>
              <div className="bg-black/30 p-2 rounded border border-white/[0.04]">
                <span className="text-[10px] text-slate-500 block">H1 Bias</span>
                <span className="font-bold text-emerald-400">{snapshot?.mtfBias.h1Bias || 'BULLISH'}</span>
              </div>
            </div>
          </div>

          {/* Macro Baseline & Scenarios */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Macro Data Points with strict "as of" dates */}
            <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-4 shadow-lg space-y-2.5">
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <BarChart2 className="w-3.5 h-3.5 text-[#F5C451]" />
                  MACROECONOMIC FUNDAMENTALS
                </span>
                <span className="text-[10px] text-slate-500">Explicit "As Of" Dates</span>
              </div>

              <div className="space-y-1.5 text-xs">
                {(deskData?.macro && deskData.macro.length > 0 ? deskData.macro : [
                  { id: '1', name: '10Y Real TIPS Yield', value: 1.92, formattedValue: '1.92%', asOf: '2026-09-29', biasForGold: 'BEARISH' as const, unit: '%', frequency: 'daily' as const, source: 'FRED' },
                  { id: '2', name: 'Gold Speculative Net COT', value: 268000, formattedValue: '+268k Contracts', asOf: '2026-09-26', biasForGold: 'BULLISH' as const, unit: 'contracts', frequency: 'weekly' as const, source: 'CFTC' },
                  { id: '3', name: 'Effective Fed Funds Rate', value: 4.83, formattedValue: '4.83%', asOf: '2026-09-28', biasForGold: 'NEUTRAL' as const, unit: '%', frequency: 'daily' as const, source: 'FED' },
                  { id: '4', name: 'US Core CPI (YoY)', value: 3.1, formattedValue: '3.1%', asOf: '2026-09-15', biasForGold: 'BULLISH' as const, unit: '%', frequency: 'monthly' as const, source: 'BLS' },
                ]).map((m) => (
                  <div key={m.id} className="flex justify-between items-center bg-black/20 p-2 rounded border border-white/[0.03]">
                    <div>
                      <div className="text-slate-300 font-semibold">{m.name}</div>
                      <div className="text-[9px] text-slate-500">As of {m.asOf} · {m.source}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-100">{m.formattedValue}</div>
                      <span className={`text-[9px] font-bold ${
                        m.biasForGold === 'BULLISH' ? 'text-emerald-400' : m.biasForGold === 'BEARISH' ? 'text-rose-400' : 'text-slate-400'
                      }`}>
                        {m.biasForGold}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Rolling Correlation Matrix */}
            <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-4 shadow-lg space-y-2.5">
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-purple-400" />
                  ROLLING CORRELATIONS (30D)
                </span>
                <span className="text-[10px] text-slate-500">XAUUSD Benchmark</span>
              </div>

              <div className="space-y-1.5 text-xs">
                {(deskData?.correlations && deskData.correlations.length > 0 ? deskData.correlations : [
                  { assetA: 'XAUUSD', assetB: 'DXY', windowBars: 30, correlation: -0.74, isBroken: false, divergenceReason: 'Strong inverse dollar correlation' },
                  { assetA: 'XAUUSD', assetB: 'US10Y', windowBars: 30, correlation: -0.62, isBroken: false, divergenceReason: 'Yield pressure intact' },
                  { assetA: 'XAUUSD', assetB: 'XAGUSD', windowBars: 30, correlation: 0.88, isBroken: false, divergenceReason: 'Precious metals moving in tandem' },
                  { assetA: 'XAUUSD', assetB: 'USOIL', windowBars: 30, correlation: 0.35, isBroken: false, divergenceReason: 'Mild energy inflation pass-through' },
                ]).map((c, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-black/20 p-2 rounded border border-white/[0.03]">
                    <div>
                      <div className="text-slate-300 font-semibold">{c.assetA} vs {c.assetB}</div>
                      <div className="text-[9px] text-slate-500">{c.divergenceReason || 'Normal rolling correlation'}</div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${c.correlation > 0 ? 'text-emerald-400' : 'text-cyan-400'}`}>
                        {c.correlation > 0 ? '+' : ''}{c.correlation.toFixed(2)}
                      </div>
                      <span className={`text-[9px] px-1 py-0.2 rounded ${c.isBroken ? 'bg-rose-500/20 text-rose-300' : 'bg-white/[0.04] text-slate-400'}`}>
                        {c.isBroken ? 'DECOUPLED' : 'NORMAL'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Signal Fusion Waterfall & Market Intel */}
        <div className="space-y-4">
          {/* Signal Fusion Waterfall */}
          <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#F5C451]" />
                SIGNAL FUSION WATERFALL
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#F5C451]/10 text-[#F5C451] font-bold">
                {snapshot?.grade || 'A'} Grade
              </span>
            </div>

            {/* Final Verdict Banner */}
            <div className="p-3 rounded-lg bg-black/40 border border-white/[0.05] flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 block">ALGORITHMIC VERDICT</span>
                <span className={`text-lg font-bold ${
                  snapshot?.verdict === 'BUY' ? 'text-emerald-400' : snapshot?.verdict === 'SELL' ? 'text-rose-400' : 'text-[#F5C451]'
                }`}>
                  {snapshot?.verdict || 'WAIT'}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 block">CONFIRMATION SCORE</span>
                <span className="text-lg font-bold text-slate-100">
                  {Math.max(snapshot?.buyScore || 0, snapshot?.sellScore || 0)} / 100
                </span>
              </div>
            </div>

            {/* Waterfall Layers */}
            <div className="space-y-2 text-xs">
              {[
                { label: 'Layer 1: Market Regime', value: snapshot?.regime.type || 'RANGE', score: '+15 pts', pass: true },
                { label: 'Layer 2: HTF Bias (H1/H4)', value: snapshot?.mtfBias.h1Bias || 'BULLISH', score: '+18 pts', pass: true },
                { label: 'Layer 3: Liquidity Sweeps', value: `${(snapshot?.liquidityLevels || []).filter(l => l.swept).length} swept`, score: '+12 pts', pass: true },
                { label: 'Layer 4: SMC Order Blocks & FVG', value: `${(snapshot?.orderBlocks || []).length} OBs active`, score: '+16 pts', pass: true },
                { label: 'Layer 5: Momentum & VWAP', value: 'Above Session VWAP', score: '+10 pts', pass: true },
                { label: 'Layer 6: Session Kill Zone', value: snapshot?.session.currentSession || 'LONDON', score: snapshot?.session.isKillZone ? '+8 pts' : '0 pts', pass: snapshot?.session.isKillZone },
                { label: 'Layer 7: Cross-Asset & Risk-Off', value: riskOff?.type || 'SAFE_HAVEN_GOLD', score: '+6 pts', pass: true },
              ].map((step, idx) => (
                <div key={idx} className="bg-white/[0.02] p-2 rounded border border-white/[0.04] space-y-1">
                  <div className="flex justify-between items-center text-[11px]">
                    <span className="text-slate-300 font-semibold">{step.label}</span>
                    <span className="text-emerald-400 font-bold">{step.score}</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>{step.value}</span>
                    {step.pass && <CheckCircle className="w-3 h-3 text-emerald-400" />}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Market Intelligence & Geopolitical Risk (GRI) */}
          <div className="bg-[#0b0f17] border border-white/[0.06] rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                MARKET INTELLIGENCE & GRI
              </span>
              <span className="text-[10px] text-slate-400">GDELT Registry</span>
            </div>

            {/* GRI Gauge */}
            <div className="bg-black/30 p-3 rounded-lg border border-white/[0.04] space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Geopolitical Risk Index (GRI):</span>
                <span className="font-bold text-[#F5C451]">{gri} / 100</span>
              </div>
              <div className="w-full bg-white/[0.05] h-2 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500"
                  style={{ width: `${gri}%` }}
                />
              </div>
              <div className="text-[10px] text-slate-500">
                {gri > 60 ? 'Elevated geopolitical tension supports gold safe-haven bid.' : 'Moderate geopolitical background.'}
              </div>
            </div>

            {/* Unscheduled Shock Alert */}
            {shock && shock.status === 'ACTIVE' ? (
              <div className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
                  <span>UNSCHEDULED MARKET SHOCK DETECTED</span>
                </div>
                <div className="text-[10px] text-rose-200">
                  Velocity: {shock.velocityAtr.toFixed(1)}x ATR | Spread Multiplier: {shock.spreadMultiplier.toFixed(1)}x
                </div>
              </div>
            ) : (
              <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Shock Detector: Normal Flow (No micro-flash anomalies)</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
