import { DeepSeekReview, FullAnalysisResult, SignalAgreement, SignalEntity, SignalSource } from '../types.ts';
import { sqliteStore } from '../db/sqliteStore.ts';
import { liveOutcomeTracker } from '../market/outcomeTracker.ts';
import { getSignalSourceConfig } from './sourceConfig.ts';
import { formatSourceSignalGroupHtml, sendTelegramHtmlMessage } from '../telegram/bot.ts';

export interface SignalCreatedEvent {
  type: 'signal_created';
  groupId: string;
  agreement: SignalAgreement;
  signals: SignalEntity[];
}

export class SignalEmitter {
  private readonly technicalTriggerCodes = new Set(['S', 'F', 'K', 'O']);
  private readonly signalCreatedListeners = new Set<(event: SignalCreatedEvent) => void>();

  public onSignalCreated(listener: (event: SignalCreatedEvent) => void) {
    this.signalCreatedListeners.add(listener);
    return () => this.signalCreatedListeners.delete(listener);
  }

  private prepare(
    source: Exclude<SignalSource, 'UNKNOWN_LEGACY'>,
    analysis: FullAnalysisResult,
    candleCloseTs: number,
    aiReview?: DeepSeekReview | null
  ): Omit<SignalEntity, 'snapshotHash' | 'prevHash' | 'source' | 'hashVersion'> | null {
    const config = getSignalSourceConfig(source);
    const plan = analysis.tradePlan;
    if (!config.enabled || candleCloseTs <= 0 || analysis.isStale || analysis.isPriceDivergent || analysis.hardBlockReason || !plan || !plan.riskRewardValid || !analysis.signalLock.isLocked) return null;

    const direction = analysis.verdict === 'BUY' || analysis.verdict === 'SELL' ? analysis.verdict : null;
    if (!direction) return null;
    const score = direction === 'BUY' ? analysis.buyScore : analysis.sellScore;
    const grade = analysis.grade;
    const gradeOrder = { 'A+': 5, A: 4, B: 3, C: 2, X: 1 } as const;
    const minGradeOrder = { 'A+': 5, A: 4, B: 3, C: 2, X: 1 } as const;
    if (score < config.minScore || gradeOrder[grade] < minGradeOrder[config.minGrade]) return null;

    const factorsForDirection = direction === 'BUY' ? analysis.buyFactors : analysis.sellFactors;
    const technicalPasses = factorsForDirection.filter((factor) => this.technicalTriggerCodes.has(factor.code) && factor.status === 'pass').length;
    if (technicalPasses < config.minimumTechnicalPasses) return null;

    if (source === 'ANALYSIS' && aiReview && (aiReview.verdict === 'WAIT' || aiReview.verdict !== direction)) return null;
    if (source === 'ANALYSIS' && !aiReview && config.aiOfflineMode === 'BLOCK') return null;

    const latest = sqliteStore.getAllSignals({ source, origin: 'engine_live', direction, limit: 1 }).signals[0];
    if (latest && candleCloseTs - latest.candleCloseTs < config.cooldownSeconds) return null;

    const factors = factorsForDirection
      .filter((factor) => factor.status === 'pass')
      .map((factor) => ({ code: factor.code, name: factor.name, reason: factor.reason, weight: factor.weight }));
    const modelReview = source === 'ANALYSIS' ? aiReview ?? undefined : undefined;
    const aiState: SignalEntity['aiState'] = source !== 'ANALYSIS'
      ? 'NOT_USED'
      : modelReview
        ? 'ONLINE'
        : 'RULE_FUSION_ONLY';
    const factorEvidence = factorsForDirection.map((factor) => ({
      code: factor.code,
      status: factor.status,
      scoreContribution: factor.scoreContribution,
      sourceProof: factor.sourceProof,
    }));
    const technicalCodes = new Set(['S', 'H', 'F', 'K', 'O', 'T', 'REG', '4H', 'D1', 'VWAP', 'MOM', 'RAIL']);
    const configVersion = `${source.toLowerCase()}-${config.version}`;
    const id = `${source.toLowerCase()}_${analysis.symbol}_${analysis.timeframe}_${candleCloseTs}_${direction}_${config.version}`;

    return {
      id,
      createdTs: candleCloseTs,
      candleCloseTs,
      symbol: analysis.symbol,
      sourceFeed: 'OANDA:XAUUSD',
      direction,
      triggerTf: analysis.timeframe,
      entryType: plan.entryType === 'LIMIT' ? 'LIMIT_RETEST' : 'MARKET',
      entryPrice: plan.entryPrice,
      sl: plan.stopLoss,
      tp1: plan.tp1,
      tp2: plan.tp2,
      tp3: plan.tp3,
      rrPlanned: plan.rr1,
      score,
      grade,
      regime: analysis.regime.type,
      session: analysis.session.currentSession,
      factors,
      weightsVersion: config.version,
      configVersion,
      aiVerdict: modelReview ? {
        verdict: modelReview.verdict,
        agreement: modelReview.agreement,
        modelUsed: modelReview.modelUsed,
        reviewedAt: modelReview.reviewedAt,
      } : undefined,
      priceFeedSnapshot: {
        primaryPrice: analysis.currentPrice,
        secondaryPrice: analysis.secondaryPrice,
        spread: analysis.spread,
        latencyMs: analysis.dataAgeMs,
      },
      mgmtPlan: {
        partialCloseTp1Percent: plan.partialCloseTp1Percent,
        partialCloseTp2Percent: plan.partialCloseTp2Percent,
        moveSlToBreakEvenAtTp1: plan.moveSlToBreakEvenAtTp1,
        maxCandlesTimeStop: plan.timeStopMaxCandles,
      },
      brokerOffset: 0,
      tags: ['algorithmic', grade.toLowerCase()],
      origin: 'engine_live',
      agreement: 'SOLO',
      inputProvenance: {
        engineVersion: config.version,
        factorEvidence,
        technicalFactorCodes: factorEvidence.filter((factor) => technicalCodes.has(factor.code)).map((factor) => factor.code),
        contextFactorCodes: source === 'ANALYSIS'
          ? factorEvidence.filter((factor) => !technicalCodes.has(factor.code)).map((factor) => factor.code)
          : [],
        session: analysis.session.currentSession,
        regime: analysis.regime.type,
        riskOff: analysis.riskOff?.type ?? null,
        griIndex: analysis.griIndex,
        newsSources: source === 'ANALYSIS' ? (analysis.recentStories || []).map((story) => story.source) : [],
        quoteAgeMs: analysis.dataAgeMs,
        priceDivergenceAtr: analysis.priceDivergenceAtr,
        aiModel: modelReview?.modelUsed ?? null,
      },
      aiState,
    };
  }

  public emitClosedCandlePair(
    indicatorAnalysis: FullAnalysisResult,
    analysisAnalysis: FullAnalysisResult,
    candleCloseTs: number,
    aiReview?: DeepSeekReview | null
  ): SignalEntity[] {
    const candidates = [
      { source: 'INDICATOR' as const, signalInput: this.prepare('INDICATOR', indicatorAnalysis, candleCloseTs) },
      { source: 'ANALYSIS' as const, signalInput: this.prepare('ANALYSIS', analysisAnalysis, candleCloseTs, aiReview) },
    ].filter((candidate): candidate is { source: 'INDICATOR' | 'ANALYSIS'; signalInput: NonNullable<typeof candidate.signalInput> } => Boolean(candidate.signalInput));
    if (candidates.length === 0) return [];

    const groupId = `group_${indicatorAnalysis.symbol}_${indicatorAnalysis.timeframe}_${candleCloseTs}`;
    const agreement: SignalAgreement = candidates.length === 1
      ? 'SOLO'
      : candidates[0].signalInput.direction === candidates[1].signalInput.direction
        ? 'BOTH_SAME_DIR'
        : 'OPPOSITE_DIR';
    const entries = candidates.map(({ source, signalInput }) => ({
      source,
      signalInput: { ...signalInput, groupId, agreement },
    }));
    const { signals: savedSignals, createdSignals } = sqliteStore.createFromEngineBatch(entries);
    for (const signal of savedSignals) {
      if (createdSignals.some((created) => created.id === signal.id)) {
        liveOutcomeTracker.registerSignal(signal);
      }
    }
    if (createdSignals.length > 0) {
      const event: SignalCreatedEvent = {
        type: 'signal_created',
        groupId,
        agreement,
        signals: createdSignals,
      };
      for (const listener of this.signalCreatedListeners) listener(event);
      void sendTelegramHtmlMessage(formatSourceSignalGroupHtml(createdSignals));
    }
    return savedSignals;
  }
}

export const signalEmitter = new SignalEmitter();
