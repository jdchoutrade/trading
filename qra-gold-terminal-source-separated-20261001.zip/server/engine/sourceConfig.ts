import fs from 'node:fs';
import path from 'node:path';
import { SignalSource } from '../types.ts';
import { RegimeWeightsConfig } from './defaultWeights.ts';

export interface SignalSourceConfig {
  version: string;
  enabled: boolean;
  minScore: number;
  minGrade: 'A+' | 'A' | 'B' | 'C' | 'X';
  cooldownSeconds: number;
  minimumTechnicalPasses: number;
  aiOfflineMode?: 'RULE_FUSION_ONLY' | 'BLOCK';
  weights: RegimeWeightsConfig;
}

const configPaths: Record<Exclude<SignalSource, 'UNKNOWN_LEGACY'>, string> = {
  INDICATOR: 'weights.indicator.json',
  ANALYSIS: 'weights.analysis.json',
};
const loaded = new Map<string, SignalSourceConfig>();

function validate(config: SignalSourceConfig, filePath: string): SignalSourceConfig {
  const validGrades = ['A+', 'A', 'B', 'C', 'X'];
  const weightKeys = ['S', 'H', 'F', 'K', 'O', 'T', 'REG', '4H', 'D1', 'VWAP', 'MOM', 'RAIL', 'XA', 'COR', 'MAC', 'NEWS', 'GEO'];
  if (
    typeof config.version !== 'string'
    || typeof config.enabled !== 'boolean'
    || !Number.isFinite(config.minScore)
    || config.minScore < 0
    || config.minScore > 100
    || !Number.isFinite(config.cooldownSeconds)
    || config.cooldownSeconds < 0
    || !Number.isInteger(config.minimumTechnicalPasses)
    || config.minimumTechnicalPasses < 0
    || !validGrades.includes(config.minGrade)
    || (config.aiOfflineMode !== undefined && config.aiOfflineMode !== 'RULE_FUSION_ONLY' && config.aiOfflineMode !== 'BLOCK')
    || !config.weights?.TREND
    || !config.weights?.RANGE
    || !config.weights?.HIGH_VOLATILITY
  ) {
    throw new Error(`Invalid signal source configuration: ${filePath}`);
  }

  for (const regime of [config.weights.TREND, config.weights.RANGE, config.weights.HIGH_VOLATILITY]) {
    for (const key of weightKeys) {
      const value = regime[key as keyof typeof regime];
      if (!Number.isFinite(value) || value < 0) throw new Error(`Invalid source weight in ${filePath}`);
    }
  }
  return config;
}

export function getSignalSourceConfig(source: Exclude<SignalSource, 'UNKNOWN_LEGACY'>): SignalSourceConfig {
  const existing = loaded.get(source);
  if (existing) return existing;

  const filePath = path.resolve(process.cwd(), configPaths[source]);
  const parsed = validate(JSON.parse(fs.readFileSync(filePath, 'utf8')) as SignalSourceConfig, filePath);
  loaded.set(source, parsed);
  return parsed;
}

export function updateSignalSourceConfig(
  source: Exclude<SignalSource, 'UNKNOWN_LEGACY'>,
  updates: Partial<Pick<SignalSourceConfig, 'enabled' | 'minScore' | 'minGrade' | 'cooldownSeconds' | 'minimumTechnicalPasses' | 'aiOfflineMode' | 'weights'>>
): SignalSourceConfig {
  const config = getSignalSourceConfig(source);
  const filePath = path.resolve(process.cwd(), configPaths[source]);
  const next = validate({
    ...config,
    ...updates,
    version: `${source.toLowerCase()}-${Date.now()}`,
  }, filePath);
  const temporaryPath = `${filePath}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(next, null, 2)}\n`, 'utf8');
  fs.renameSync(temporaryPath, filePath);
  loaded.set(source, next);
  return next;
}
