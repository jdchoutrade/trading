import { Candle, Timeframe } from '../types.ts';
import { requestAiReview } from '../ai/deepseek.ts';
import { marketIntelligence } from '../intel/marketIntelligence.ts';
import { marketProvider } from '../market/dataProvider.ts';
import { tvFeed } from '../market/tvFeed.ts';
import { runFullAnalysisPipeline } from './pipeline.ts';
import { getSignalSourceConfig } from './sourceConfig.ts';
import { signalEmitter } from './signalEmitter.ts';

const triggerTimeframe: Timeframe = process.env.SIGNAL_TRIGGER_TF === '5m' ? '5m' : '15m';
const timeframeSeconds: Record<Timeframe, number> = {
  '1m': 60,
  '5m': 300,
  '15m': 900,
  '1h': 3600,
  '4h': 14400,
  D: 86400,
};

function closedCandles(candles: Candle[], latestClosed: Candle): Candle[] {
  const byTime = new Map(candles.filter((candle) => !candle.isForming).map((candle) => [candle.time, candle]));
  byTime.set(latestClosed.time, { ...latestClosed, isForming: false });
  return [...byTime.values()].sort((a, b) => a.time - b.time);
}

function atOrBefore(candles: Candle[], closeTime: number): Candle[] {
  return candles.filter((candle) => !candle.isForming && candle.time <= closeTime);
}

async function analyzeClosedCandle(candle: Candle) {
  const health = marketProvider.getHealth();
  const symbolData = marketProvider.getSymbolData('XAUUSD');
  if (!symbolData || !health.isConnected || health.status !== 'LIVE' || health.isDelayed || health.isDelayed15m || symbolData.isStale) {
    return;
  }

  const closeTs = candle.time + timeframeSeconds[triggerTimeframe];
  if (closeTs > Math.floor(Date.now() / 1000)) return;

  const candles = closedCandles(marketProvider.getCandles('XAUUSD', triggerTimeframe), candle);
  if (candles.length < 50 || candles[candles.length - 1].time !== candle.time) return;

  const m1 = atOrBefore(marketProvider.getCandles('XAUUSD', '1m'), candle.time);
  const m5 = atOrBefore(marketProvider.getCandles('XAUUSD', '5m'), candle.time);
  const m15 = candles;
  const h1 = atOrBefore(marketProvider.getCandles('XAUUSD', '1h'), candle.time);
  const h4 = atOrBefore(marketProvider.getCandles('XAUUSD', '4h'), candle.time);
  const d1 = atOrBefore(marketProvider.getCandles('XAUUSD', 'D'), candle.time);
  const multiTf = { m1, m5, m15, h1, h4, d1 };
  const indicatorConfig = getSignalSourceConfig('INDICATOR');
  const analysisConfig = getSignalSourceConfig('ANALYSIS');
  if (!indicatorConfig.enabled && !analysisConfig.enabled) return;

  const crossAssets = marketIntelligence.getCrossAssets();
  const correlations = marketIntelligence.getCorrelationMatrix();
  const stories = marketIntelligence.getStories();
  const riskOff = marketIntelligence.getRiskOff();
  const griIndex = marketIntelligence.getGriIndex();
  const activeShock = marketIntelligence.checkUnscheduledShock(candles, 6.0, symbolData.spread);

  const common = {
    symbol: 'XAUUSD',
    timeframe: triggerTimeframe,
    currentPrice: symbolData.currentPrice,
    candles,
    multiTf,
    spread: symbolData.spread,
    isStale: symbolData.isStale,
    isDelayed: symbolData.isDelayed || health.isDelayed,
    dataAgeMs: symbolData.latencyMs,
    secondaryPrice: symbolData.secondaryPrice || symbolData.currentPrice,
    isPriceDivergent: symbolData.isDivergent,
    divergenceAtr: symbolData.divergenceAtr || 0,
    riskOff,
    griIndex,
    crossAssets,
    correlations,
    stories,
    activeShock: activeShock || undefined,
  };

  const indicator = runFullAnalysisPipeline({
    ...common,
    sourceWeights: indicatorConfig.weights,
  });
  const analysis = runFullAnalysisPipeline({
    ...common,
    sourceWeights: analysisConfig.weights,
  });

  const recentHighImpactStory = stories.some((story) =>
    story.verificationStatus !== 'UNVERIFIED'
    && story.severity >= 8
    && Date.now() / 1000 - story.receivedAt <= 15 * 60
  );
  if (recentHighImpactStory || activeShock) return;

  const aiReview = analysisConfig.enabled
    ? await requestAiReview(analysis, undefined, { allowRuleFallback: false, useCache: false })
    : null;
  if (aiReview) analysis.deepSeekReview = aiReview;
  signalEmitter.emitClosedCandlePair(indicator, analysis, closeTs, aiReview);
}

let unsubscribe: (() => void) | undefined;
export function startSourceIngest(): () => void {
  if (unsubscribe) return unsubscribe;
  unsubscribe = tvFeed.onCandleClose((timeframe, candle) => {
    if (timeframe !== triggerTimeframe) return;
    void analyzeClosedCandle(candle).catch((error: unknown) => {
      console.error('Closed-candle source analysis failed:', error);
    });
  });
  return unsubscribe;
}
