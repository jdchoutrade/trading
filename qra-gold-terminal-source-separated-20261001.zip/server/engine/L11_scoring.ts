import {
  Candle,
  LiquidityLevel,
  OrderBlock,
  SignalGrade,
  SignalLock,
  SignalVerdict,
  TradePlan,
} from '../types.ts';
import { calculateATR } from './indicators.ts';

export interface ScoringInput {
  buyScore: number;
  sellScore: number;
  currentPrice: number;
  candles: Candle[];
  orderBlocks: OrderBlock[];
  liquidityLevels: LiquidityLevel[];
  isHardBlocked: boolean;
  currentLock?: SignalLock;
  accountSize?: number;
  riskPercent?: number;
}

export interface ScoringOutput {
  verdict: SignalVerdict;
  grade: SignalGrade;
  signalLock: SignalLock;
  tradePlan?: TradePlan;
}

export function computeSignalAndTradePlan(input: ScoringInput): ScoringOutput {
  const {
    buyScore,
    sellScore,
    currentPrice,
    candles,
    orderBlocks,
    liquidityLevels,
    isHardBlocked,
    currentLock,
    accountSize = 10000,
    riskPercent = 1.0,
  } = input;

  const nowSec = Math.floor(Date.now() / 1000);
  const atrs = calculateATR(candles, 14);
  const currentATR = Math.max(0.5, atrs[atrs.length - 1] || 2.0);

  // Check existing lock
  if (currentLock && currentLock.isLocked && currentLock.lockUntil > nowSec) {
    const isInvalidated =
      currentLock.invalidationLevel &&
      ((currentLock.lockedVerdict === 'BUY' && currentPrice < currentLock.invalidationLevel) ||
        (currentLock.lockedVerdict === 'SELL' && currentPrice > currentLock.invalidationLevel));

    if (!isInvalidated) {
      const remainingMinutes = Math.max(0, Math.round((currentLock.lockUntil - nowSec) / 60));
      return {
        verdict: currentLock.lockedVerdict || 'WAIT',
        grade: 'A',
        signalLock: {
          ...currentLock,
          remainingMinutes,
        },
      };
    }
  }

  if (isHardBlocked) {
    return {
      verdict: 'WAIT',
      grade: 'X',
      signalLock: { isLocked: false, lockUntil: 0, remainingMinutes: 0 },
    };
  }

  // Determine top score & direction
  const maxScore = Math.max(buyScore, sellScore);
  const direction: 'BUY' | 'SELL' = buyScore >= sellScore ? 'BUY' : 'SELL';

  let grade: SignalGrade = 'X';
  if (maxScore >= 85) grade = 'A+';
  else if (maxScore >= 75) grade = 'A';
  else if (maxScore >= 65) grade = 'B';
  else if (maxScore >= 50) grade = 'C';
  else grade = 'X';

  let verdict: SignalVerdict = 'WAIT';
  if (maxScore >= 75) {
    verdict = direction;
  } else if (maxScore >= 55) {
    verdict = direction === 'BUY' ? 'BUY_LEANS' : 'SELL_LEANS';
  } else {
    verdict = 'WAIT';
  }

  // Calculate Trade Plan if verdict is actionable (A+, A, or B lean)
  let tradePlan: TradePlan | undefined;
  let signalLock: SignalLock = {
    isLocked: false,
    lockUntil: 0,
    remainingMinutes: 0,
  };

  if (verdict === 'BUY' || (verdict === 'BUY_LEANS' && maxScore >= 65)) {
    // BUY SETUP
    const nearbyOB = orderBlocks.find((ob) => ob.type === 'BULLISH' && !ob.mitigated && ob.high <= currentPrice + 2);
    const entryPrice = nearbyOB ? nearbyOB.mid : currentPrice;

    // SL: behind OB low or recent swing low - 0.3 ATR
    const baseSL = nearbyOB ? nearbyOB.low - 0.3 * currentATR : currentPrice - 1.4 * currentATR;
    const slDistance = Math.min(2.5 * currentATR, Math.max(1.2 * currentATR, currentPrice - baseSL));
    const stopLoss = Number((entryPrice - slDistance).toFixed(2));
    const slAtrMultiple = Number((slDistance / currentATR).toFixed(2));

    // Target liquidity pools above price
    const buySideLiquidity = liquidityLevels
      .filter((l) => (l.type === 'SWING_HIGH' || l.type === 'EQUAL_HIGH' || l.type === 'ROUND_NUMBER') && l.price > entryPrice)
      .sort((a, b) => a.price - b.price);

    const tp1 = buySideLiquidity[0] ? buySideLiquidity[0].price : Number((entryPrice + slDistance * 1.5).toFixed(2));
    const tp2 = buySideLiquidity[1] ? buySideLiquidity[1].price : Number((entryPrice + slDistance * 2.6).toFixed(2));
    const tp3 = buySideLiquidity[2] ? buySideLiquidity[2].price : Number((entryPrice + slDistance * 5.0).toFixed(2));

    const rr1 = Number(((tp1 - entryPrice) / slDistance).toFixed(2));
    const rr2 = Number(((tp2 - entryPrice) / slDistance).toFixed(2));
    const rr3 = Number(((tp3 - entryPrice) / slDistance).toFixed(2));

    const riskRewardValid = rr1 >= 1.4;

    // Lot Size calculation: (Account * Risk%) / (SL in points * 100)
    const riskDollar = (accountSize * riskPercent) / 100;
    const lotSize = Number((riskDollar / (slDistance * 100)).toFixed(2));

    tradePlan = {
      entryType: nearbyOB ? 'LIMIT' : 'MARKET',
      entryPrice: Number(entryPrice.toFixed(2)),
      stopLoss,
      slAtrMultiple,
      tp1,
      tp2,
      tp3,
      rr1,
      rr2,
      rr3,
      riskRewardValid,
      suggestedLotSize: Math.max(0.01, lotSize),
      invalidationLevel: stopLoss,
      partialCloseTp1Percent: 50,
      partialCloseTp2Percent: 30,
      moveSlToBreakEvenAtTp1: true,
      trailingStopRule: 'Trail behind structural swing high/low once TP1 reached',
      timeStopMaxCandles: 8,
    };

    if (verdict === 'BUY' && riskRewardValid) {
      signalLock = {
        isLocked: true,
        lockUntil: nowSec + 20 * 60, // 20 minutes
        lockedVerdict: 'BUY',
        invalidationLevel: stopLoss,
        remainingMinutes: 20,
      };
    }
  } else if (verdict === 'SELL' || (verdict === 'SELL_LEANS' && maxScore >= 65)) {
    // SELL SETUP
    const nearbyOB = orderBlocks.find((ob) => ob.type === 'BEARISH' && !ob.mitigated && ob.low >= currentPrice - 2);
    const entryPrice = nearbyOB ? nearbyOB.mid : currentPrice;

    const baseSL = nearbyOB ? nearbyOB.high + 0.3 * currentATR : currentPrice + 1.4 * currentATR;
    const slDistance = Math.min(2.5 * currentATR, Math.max(1.2 * currentATR, baseSL - currentPrice));
    const stopLoss = Number((entryPrice + slDistance).toFixed(2));
    const slAtrMultiple = Number((slDistance / currentATR).toFixed(2));

    const sellSideLiquidity = liquidityLevels
      .filter((l) => (l.type === 'SWING_LOW' || l.type === 'EQUAL_LOW' || l.type === 'ROUND_NUMBER') && l.price < entryPrice)
      .sort((a, b) => b.price - a.price);

    const tp1 = sellSideLiquidity[0] ? sellSideLiquidity[0].price : Number((entryPrice - slDistance * 1.5).toFixed(2));
    const tp2 = sellSideLiquidity[1] ? sellSideLiquidity[1].price : Number((entryPrice - slDistance * 2.6).toFixed(2));
    const tp3 = sellSideLiquidity[2] ? sellSideLiquidity[2].price : Number((entryPrice - slDistance * 5.0).toFixed(2));

    const rr1 = Number(((entryPrice - tp1) / slDistance).toFixed(2));
    const rr2 = Number(((entryPrice - tp2) / slDistance).toFixed(2));
    const rr3 = Number(((entryPrice - tp3) / slDistance).toFixed(2));

    const riskRewardValid = rr1 >= 1.4;

    const riskDollar = (accountSize * riskPercent) / 100;
    const lotSize = Number((riskDollar / (slDistance * 100)).toFixed(2));

    tradePlan = {
      entryType: nearbyOB ? 'LIMIT' : 'MARKET',
      entryPrice: Number(entryPrice.toFixed(2)),
      stopLoss,
      slAtrMultiple,
      tp1,
      tp2,
      tp3,
      rr1,
      rr2,
      rr3,
      riskRewardValid,
      suggestedLotSize: Math.max(0.01, lotSize),
      invalidationLevel: stopLoss,
      partialCloseTp1Percent: 50,
      partialCloseTp2Percent: 30,
      moveSlToBreakEvenAtTp1: true,
      trailingStopRule: 'Trail behind structural swing high/low once TP1 reached',
      timeStopMaxCandles: 8,
    };

    if (verdict === 'SELL' && riskRewardValid) {
      signalLock = {
        isLocked: true,
        lockUntil: nowSec + 20 * 60,
        lockedVerdict: 'SELL',
        invalidationLevel: stopLoss,
        remainingMinutes: 20,
      };
    }
  }

  return {
    verdict,
    grade,
    signalLock,
    tradePlan,
  };
}
