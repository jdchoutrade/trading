import {
  Candle,
  CorrelationMatrixItem,
  CrossAssetQuote,
  FullAnalysisResult,
  MarketNewsStory,
  RiskOffClassification,
  ShockAlert,
  Timeframe,
} from '../types.ts';
import { calculateATR } from './indicators.ts';
import { detectMarketRegime } from './L1_regime.ts';
import { analyzeMultiTimeframe } from './L2_multitimeframe.ts';
import { identifyLiquidityLevels } from './L3_liquidity.ts';
import { detectBOSAndCHoCH, detectFVGs, detectLiquiditySweeps, detectOrderBlocks } from './L4_smc.ts';
import { analyzeCandlePatterns, analyzeMomentum, analyzeVolumeAndVWAP } from './L5_L8_patterns.ts';
import { analyzeSession } from './L9_session.ts';
import { evaluateConfirmations } from './L10_confirmation.ts';
import { computeSignalAndTradePlan } from './L11_scoring.ts';
import { RegimeWeightsConfig } from './defaultWeights.ts';

export interface PipelineMultiTfCandles {
  m1?: Candle[];
  m5?: Candle[];
  m15?: Candle[];
  h1?: Candle[];
  h4?: Candle[];
  d1?: Candle[];
}

export function runFullAnalysisPipeline(params: {
  symbol: string;
  timeframe: Timeframe;
  currentPrice: number;
  candles: Candle[];
  multiTf?: PipelineMultiTfCandles;
  spread?: number;
  isStale?: boolean;
  isDelayed?: boolean;
  dataAgeMs?: number;
  secondaryPrice?: number;
  isPriceDivergent?: boolean;
  divergenceAtr?: number;
  riskOff?: RiskOffClassification;
  griIndex?: number;
  crossAssets?: CrossAssetQuote[];
  correlations?: CorrelationMatrixItem[];
  stories?: MarketNewsStory[];
  activeShock?: ShockAlert;
  sourceWeights?: RegimeWeightsConfig;
}): FullAnalysisResult {
  const {
    symbol,
    timeframe,
    currentPrice,
    candles,
    multiTf = {},
    spread = 0.35,
    isStale = false,
    isDelayed = false,
    dataAgeMs = 35,
    secondaryPrice = currentPrice,
    isPriceDivergent = false,
    divergenceAtr = 0,
    riskOff,
    griIndex = 45,
    crossAssets = [],
    correlations = [],
    stories = [],
    activeShock,
    sourceWeights,
  } = params;

  const m1Candles = multiTf.m1 || candles;
  const m5Candles = multiTf.m5 || candles;
  const m15Candles = multiTf.m15 || candles;
  const h1Candles = multiTf.h1 || candles;
  const h4Candles = multiTf.h4 || candles;

  // L1: Regime
  const regime = detectMarketRegime(candles);

  // L2: Multi-Timeframe Bias
  const mtfBias = analyzeMultiTimeframe(m1Candles, m5Candles, m15Candles, h1Candles, h4Candles);

  // L3: Liquidity Levels
  const liquidityLevels = identifyLiquidityLevels(candles, timeframe);

  // L4: SMC Engine
  const breaks = detectBOSAndCHoCH(candles, liquidityLevels, timeframe);
  const orderBlocks = detectOrderBlocks(candles, timeframe);
  const fvgs = detectFVGs(candles, timeframe);
  const sweeps = detectLiquiditySweeps(candles, liquidityLevels);

  // L5 - L8: Indicators & Patterns
  const momentum = analyzeMomentum(candles);
  const volume = analyzeVolumeAndVWAP(candles);
  const patterns = analyzeCandlePatterns(candles);

  // L9: Session
  const session = analyzeSession(candles, candles[candles.length - 1]?.time);

  // L10: Confirmations (Includes V2 Cross-Asset, Correlation, Macro, News, GRI factors)
  const confirmations = evaluateConfirmations({
    candles,
    regime,
    mtfBias,
    session,
    liquidityLevels,
    orderBlocks,
    fvgs,
    breaks,
    sweeps,
    momentum,
    volume,
    patterns,
    isStale,
    isDelayed,
    spread,
    isPriceDivergent,
    divergenceAtr,
    riskOffType: riskOff?.type,
    griIndex,
    crossAssets,
    correlations,
    stories,
    customWeights: sourceWeights?.[
      regime.type === 'HIGH_VOLATILITY' ? 'HIGH_VOLATILITY' : regime.type === 'RANGE' ? 'RANGE' : 'TREND'
    ],
  });

  // L11: Scoring & Trade Plan
  const scoring = computeSignalAndTradePlan({
    buyScore: confirmations.buyScore,
    sellScore: confirmations.sellScore,
    currentPrice,
    candles,
    orderBlocks,
    liquidityLevels,
    isHardBlocked: confirmations.isHardBlocked,
  });

  const atrs = calculateATR(candles, 14);
  const atr14 = Number((atrs[atrs.length - 1] || 1.8).toFixed(2));

  return {
    symbol,
    timeframe,
    timestamp: Math.floor(Date.now() / 1000),
    currentPrice: Number(currentPrice.toFixed(2)),
    bid: Number((currentPrice - spread / 2).toFixed(2)),
    ask: Number((currentPrice + spread / 2).toFixed(2)),
    spread: Number(spread.toFixed(2)),
    atr14,
    primaryPrice: Number(currentPrice.toFixed(2)),
    secondaryPrice: Number(secondaryPrice.toFixed(2)),
    priceDivergenceAtr: Number(divergenceAtr.toFixed(2)),
    isPriceDivergent,
    regime,
    mtfBias,
    session,
    liquidityLevels,
    orderBlocks,
    fvgs,
    recentBreaks: breaks,
    recentSweeps: sweeps,
    buyFactors: confirmations.buyFactors,
    sellFactors: confirmations.sellFactors,
    buyScore: confirmations.buyScore,
    sellScore: confirmations.sellScore,
    verdict: scoring.verdict,
    grade: scoring.grade,
    signalLock: scoring.signalLock,
    tradePlan: scoring.tradePlan,
    isStale,
    dataAgeMs,
    hardBlockReason: confirmations.blockReason,
    hardBlockReasonKm: confirmations.blockReasonKm,
    riskOff,
    griIndex,
    recentStories: stories.slice(0, 5),
    activeShock,
  };
}
