# QRA Gold Terminal — Advanced SMC/ICT Technical Analysis for XAUUSD

[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-19-cyan.svg)](https://react.dev/)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-v4-38bdf8.svg)](https://tailwindcss.com/)
[![Engine](https://img.shields.io/badge/Architecture-L1--L12_Pipeline-gold.svg)]()

> **English:** High-precision Smart Money Concepts (SMC) & ICT quantitative trading terminal for XAUUSD (Gold) and multi-asset markets with AI verification, real-time liquidity mapping, and automated confirmation engine.
>
> **ភាសាខ្មែរ:** ប្រព័ន្ធ Technical Analysis កម្រិតខ្ពស់សម្រាប់ XAUUSD (Gold) ដំណើរការដោយ Smart Money Concepts (SMC), ICT, Multi-Timeframe Alignment, និង AI Verification យ៉ាងពេញលេញ និងត្រឹមត្រូវតាមក្បួនខ្នាតស្ថាប័នធនាគារ។

---

## 🏛️ 12-Step Quantitative Pipeline Architecture

```text
MARKET DATA (Real-Time Feed & Live Ticks)
   ↓
[L1] MARKET REGIME: Trend / Range / High-Volatility (ADX, ATR percentile, BB width)
   ↓
[L2] MULTI-TIMEFRAME: H1 Bias → M15 Structure → M5/M1 Entry Trigger
   ↓
[L3] LIQUIDITY MAP: Swing High/Low, Session H/L (Asia/London/NY), PDH/PDL, Round Levels
   ↓
[L4] SMC ENGINE: BOS / CHoCH / Order Block / FVG / Premium-Discount / Liquidity Sweeps
   ↓
[L5] MOMENTUM: RSI (+divergence), MACD slope, ADX/DI Cross
   ↓
[L6] VOLATILITY: ATR(14), Bollinger Squeeze & Expansion
   ↓
[L7] VOLUME: Volume Spike (>1.8× SMA20), Session VWAP (±1σ bands)
   ↓
[L8] CANDLE PATTERNS: Engulfing, Rejection Wick (≥60% range), Inside-bar break
   ↓
[L9] SESSION FILTER: Kill Zones (London, NY, Overlap) & Rollover Spread Block
   ↓
[L10] CONFIRMATION ENGINE: Weighted scoring (S, H, F, K, O, T, REG, 4H, D1, VWAP, MOM, RAIL, BLOCK)
   ↓
[L11] SIGNAL SCORE 0–100: Grades A+ (≥85), A (≥75), B (≥65), C (≥50), X (<50) + 20min Signal Lock
   ↓
[L12] AI REVIEW (DeepSeek / Gemini): Second opinion, agreement %, strict JSON schema, Khmer/EN
   ↓
FINAL OUTPUT: BUY / SELL / WAIT (+ Entry, SL, TP1/TP2/TP3, RR, Lot Size)
```

---

## ⚡ Key Features

1. **Pure Quantitative Engine (No Look-Ahead Bias):**
   - Pure functions inside `/server/engine/*.ts` thoroughly unit-tested with Vitest.
   - Dynamic weight adjustment based on Market Regime (Trend, Range, High Volatility).
2. **True Liquidity & SMC Mapping:**
   - Detects **BOS / CHoCH** strictly via candle body close.
   - **Order Block (OB)** displacement calculation and mitigation tracking.
   - **Fair Value Gaps (FVG)** imbalance identification and fill percentage tracking.
   - **Liquidity Sweeps** (sweep high/low with sharp wick rejection).
3. **Multi-Timeframe Hierarchy:**
   - Macro H1 / H4 dealing range bias.
   - Never triggers counter-trend entries against H1 bias unless confirmed by M15 CHoCH with Score ≥ 85.
4. **Session Killzones & Spread Guard:**
   - Asia Build: 00:00 - 07:00 UTC
   - London Open Killzone: 07:00 - 10:00 UTC
   - New York Open Killzone: 12:30 - 15:30 UTC
   - Overlap Window: 12:00 - 16:00 UTC
   - **Rollover Block (21:45 - 23:15 UTC):** Trading is strictly halted during wide-spread rollover.
5. **AI Second Opinion (DeepSeek & Gemini):**
   - Rate-limited and cached (60s).
   - Strict JSON validation with Zod.
   - Explanations in Khmer (ភាសាខ្មែរ) and English.
6. **Source-Tagged Signal History & Live Outcome Tracking:**
   - **SQLite Relational Persistence:** Immutable storage (`data/gold_desk.db`) with cryptographic SHA-256 hash chaining.
   - **Spread-Aware State Machine:** Automatic execution tracking (`PENDING` → `TRIGGERED` → `TP1` / `BE` / `TP2` / `TP3` / `SL`).
   - **Empirical Statistics:** Wilson 95% Confidence Intervals, Expectancy ($R/\text{trade}$), Profit Factor, Drawdown, and sample size gating ($n < 30$ insufficient sample rule).
   - **Broker Execution Sync ("I took this"):** Personal journal linked to system signals with execution gap and slippage tracking.
   - **Automated Telegram Alerts:** Real-time lifecycle notifications (Triggered, TP Hit, SL Hit, Break-Even) in Khmer & English.
7. **Risk Management & Paper Trading:**
   - Automatic lot sizing based on account equity and risk % (1.0% risk rule).
   - Real-time PnL & pip calculation.
8. **Telegram Broadcast:**
   - Clean HTML-formatted trade alerts with entry, stop loss, targets, and invalidation levels.

## Signal Sources / ប្រភព Signal

The terminal keeps two analytical sources separate:

- **INDICATOR** is deterministic SMC/price-action scoring using candle structure, liquidity, OB/FVG, regime and technical confirmations.
- **ANALYSIS** uses the same closed XAUUSD candle and shared safety gates, with separate contextual weights plus a real AI veto/review when a provider responds. A preview is not an official signal. When AI is unavailable, the configured policy either blocks the Analysis stream or labels an official rule-fusion-only result `AI OFFLINE`.
- Both streams share the same live quote/candle feed and the same spread-aware outcome tracker. They are not independent market-data samples.
- Official signals are evaluated only from a closed 5m or 15m candle. The default trigger is `15m`; set `SIGNAL_TRIGGER_TF=5m` to use `5m`.
- `signals.source` is the analytical type (`INDICATOR`, `ANALYSIS`, or `UNKNOWN_LEGACY`). `signals.origin` is lifecycle provenance (`engine_live`, `replay`, `legacy_v1`, or `UNKNOWN_LEGACY`). Old records are never guessed into an analytical type.
- History and source statistics default to `origin=engine_live`; Replay remains separate. Confluence is a view over `BOTH_SAME_DIR` groups and uses one Indicator outcome per group for its summary.
- Source configurations and independent weight matrices are `weights.indicator.json` and `weights.analysis.json`; the Settings page edits them separately. Analysis context presently includes third-party macro/correlation baselines that are not all verified live feeds, so treat those factors cautiously.
- Until at least 30 verified outcomes accrue for a source/segment, percentage-based metrics display `insufficient sample (n=...)`. The source comparison currently does not claim a bootstrap interval, random baseline, or measured AI value.

The Settings API has no authentication in the current application. Do not expose it directly to an untrusted network; use an authenticated HTTPS reverse proxy before remote access.

សញ្ញាមានពីរប្រភពដាច់ពីគ្នា៖ **INDICATOR** (ក្បួន SMC/Price Action) និង **ANALYSIS** (បន្ថែម Context និង AI ពិត)។ ទាំងពីរប្រើ candle បិទដូចគ្នា និង safety gates ដូចគ្នា។ `PREVIEW` មិនមែនជាសញ្ញាផ្លូវការ ហើយស្ថិតិមិនបញ្ចូល `Replay` ឬ `UNKNOWN_LEGACY` ដោយស្វ័យប្រវត្តិទេ។ ពេល AI មិនដំណើរការ Analysis ត្រូវបង្ហាញ `AI OFFLINE` ឬផ្អាកតាមការកំណត់។

---

## 🛠️ Verification & Replay Scripts

```bash
# Verify cryptographic hash chain & outcome determinism
npm run verify:history

# Run deterministic historical walk-forward replay backfill
npm run replay:history

# Verify live TradingView feed connectivity & latency
npm run verify:feed

# Compare multi-broker quotes (OANDA vs FOREXCOM vs TVC)
npm run symbols:compare
```

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run unit tests
npm test

# 3. Start development server
npm run dev
```

Visit `http://localhost:3000` to access the terminal.
